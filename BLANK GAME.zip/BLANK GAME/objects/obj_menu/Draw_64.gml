
/// DESENHO DO MENU

draw_set_halign(fa_center);
draw_set_valign(fa_middle);

// TÍTULO
draw_set_color(c_white);
draw_text(320, 95, "HISTÓRIA EM JOGO");

draw_set_color(c_yellow);
draw_text(320, 130, "UMA JORNADA PELO TEMPO");


// IDENTIFICAR MOUSE SOBRE OS BOTÕES

var _mx = device_mouse_x_to_gui(0);
var _my = device_mouse_y_to_gui(0);

var _hover_start =
    point_in_rectangle(
        _mx, _my,
        button_start_x,
        button_start_y,
        button_start_x + button_width,
        button_start_y + button_height
    );

var _hover_exit =
    point_in_rectangle(
        _mx, _my,
        button_exit_x,
        button_exit_y,
        button_exit_x + button_width,
        button_exit_y + button_height
    );


// BOTÃO INICIAR

if (_hover_start)
{
    draw_set_color(c_yellow);
}
else
{
    draw_set_color(c_gray);
}

draw_rectangle(
    button_start_x,
    button_start_y,
    button_start_x + button_width,
    button_start_y + button_height,
    false
);

draw_set_color(c_white);
draw_text(320, 227, "INICIAR");


// BOTÃO SAIR

if (_hover_exit)
{
    draw_set_color(c_yellow);
}
else
{
    draw_set_color(c_gray);
}

draw_rectangle(
    button_exit_x,
    button_exit_y,
    button_exit_x + button_width,
    button_exit_y + button_height,
    false
);

draw_set_color(c_white);
draw_text(320, 287, "SAIR");


// RESTAURAR CONFIGURAÇÕES

draw_set_color(c_white);
draw_set_halign(fa_left);
draw_set_valign(fa_top);
