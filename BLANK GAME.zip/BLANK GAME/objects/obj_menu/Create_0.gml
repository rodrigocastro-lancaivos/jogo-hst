
/// CONFIGURAÇÕES DO MENU

button_width = 200;
button_height = 44;

button_start_x = 220;
button_start_y = 205;

button_exit_x = 220;
button_exit_y = 265;
