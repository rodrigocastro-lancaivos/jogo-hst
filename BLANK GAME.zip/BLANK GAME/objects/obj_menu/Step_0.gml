
/// INTERAÇÃO COM O MENU

var _mx = device_mouse_x_to_gui(0);
var _my = device_mouse_y_to_gui(0);


// CLIQUE NO BOTÃO INICIAR

if (mouse_check_button_pressed(mb_left))
{
    if (point_in_rectangle(
        _mx, _my,
        button_start_x,
        button_start_y,
        button_start_x + button_width,
        button_start_y + button_height
    ))
    {
        room_goto(rm_level_01);
    }


    // CLIQUE NO BOTÃO SAIR

    if (point_in_rectangle(
        _mx, _my,
        button_exit_x,
        button_exit_y,
        button_exit_x + button_width,
        button_exit_y + button_height
    ))
    {
        game_end();
    }
}
