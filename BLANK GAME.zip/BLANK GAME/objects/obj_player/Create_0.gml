
/// CONFIGURAÇÕES DO PERSONAGEM

// Velocidade horizontal
move_speed = 4;

// Velocidade vertical
vsp = 0;

// Força do pulo
jump_speed = -10;

// Gravidade
gravity_force = 0.5;

/// CONFIGURAÇÃO DAS ANIMAÇÕES

sprite_index = spr_player_idle;

anim_state = "idle";

image_speed = 0.12;

image_xscale = 1;
