var _was_grounded = place_meeting(x, y + 1, obj_solid);

/// MOVIMENTAÇÃO HORIZONTAL

var _horizontal = keyboard_check(vk_right)
               - keyboard_check(vk_left);

// Também aceita A e D
_horizontal += keyboard_check(ord("D"))
             - keyboard_check(ord("A"));

// Limita o movimento a -1, 0 ou 1
_horizontal = clamp(_horizontal, -1, 1);

var _hsp = _horizontal * move_speed;


// PULO
if (place_meeting(x, y + 1, obj_solid))
{
    if (keyboard_check_pressed(vk_space))
    {
        vsp = jump_speed;
    }
}


// GRAVIDADE
vsp += gravity_force;
vsp = min(vsp, 12);


// MOVIMENTO HORIZONTAL COM COLISÃO
var _remaining = abs(_hsp);
var _direction = sign(_hsp);

while (_remaining >= 1)
{
    if (!place_meeting(x + _direction, y, obj_solid))
    {
        x += _direction;
    }
    else
    {
        break;
    }

    _remaining -= 1;
}


// MOVIMENTO VERTICAL COM COLISÃO
var _remaining_y = abs(vsp);
var _direction_y = sign(vsp);

while (_remaining_y >= 1)
{
    if (!place_meeting(x, y + _direction_y, obj_solid))
    {
        y += _direction_y;
    }
    else
    {
        vsp = 0;
        break;
    }

    _remaining_y -= 1;
}


/// SISTEMA DE ANIMAÇÃO

var _grounded = place_meeting(x, y + 1, obj_solid);

var _new_state = "idle";

// Verifica se está no chão
if (_grounded)
{
    if (_horizontal != 0)
    {
        _new_state = "walk";
    }
    else
    {
        _new_state = "idle";
    }
}
// Verifica se está no ar
else
{
    if (vsp < 0)
    {
        _new_state = "jump";
    }
    else
    {
        _new_state = "fall";
    }
}

// DIREÇÃO DO PERSONAGEM

if (_horizontal > 0)
{
    image_xscale = 1;
}
else if (_horizontal < 0)
{
    image_xscale = -1;
}




/// ATUALIZAÇÃO DEFINITIVA DA ANIMAÇÃO

if (anim_state != _new_state)
{
    anim_state = _new_state;

    switch (anim_state)
    {
        case "idle":
            sprite_index = spr_player_idle;
            image_speed = 0.10;
        break;

        case "walk":
            sprite_index = spr_player_walk;
            image_speed = 0.20;
        break;

        case "jump":
            sprite_index = spr_player_jump;
            image_speed = 0.15;
        break;

        case "fall":
            sprite_index = spr_player_fall;
            image_speed = 0.12;
        break;
    }

    image_index = 0;
}


show_debug_message(
    "Estado: " + string(anim_state)
    + " | Sprite: " + sprite_get_name(sprite_index)
    + " | Image speed: " + string(image_speed)
    + " | Frame: " + string(image_index)
);